# RemoteHealthCareA2
Remote healthcare project voor TI. Groep: A2.
